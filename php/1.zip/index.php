<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cálculo de Média</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }
        input, button {
            padding: 10px;
            margin: 5px 0;
            width: 100%;
            box-sizing: border-box;
        }
        .resultado {
            margin-top: 20px;
            padding: 15px;
            background: #f0f8ff;
            border-radius: 5px;
            font-weight: bold;
        }
        .error {
            color: red;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Calculadora de Média</h2>
        
        <?php
        // Processamento do formulário
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Validação dos dados
            $num1 = str_replace(',', '.', $_POST['num1'] ?? '');
            $num2 = str_replace(',', '.', $_POST['num2'] ?? '');
            $num3 = str_replace(',', '.', $_POST['num3'] ?? '');

            if (is_numeric($num1) && is_numeric($num2) && is_numeric($num3)) {
                $media = ($num1 + $num2 + $num3) / 3;
                echo "<div class='resultado'>";
                echo "<p>Números digitados: $num1, $num2, $num3</p>";
                echo "<p>Média calculada: <strong>" . number_format($media, 2, ',', '.') . "</strong></p>";
                echo "</div>";
            } else {
                echo "<p class='error'>Erro: Digite apenas números válidos!</p>";
            }
        }
        ?>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="text" name="num1" placeholder="Primeiro número" required>
            <input type="text" name="num2" placeholder="Segundo número" required>
            <input type="text" name="num3" placeholder="Terceiro número" required>
            <button type="submit">Calcular Média</button>
        </form>
    </div>
</body>
</html>