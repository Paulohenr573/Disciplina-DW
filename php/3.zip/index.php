<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cálculo de Valor Total</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            width: 100%;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        .result {
            margin-top: 20px;
            padding: 15px;
            background-color: #f0f8ff;
            border-radius: 4px;
        }
        .result p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Cálculo de Valor Total</h1>
        
        <?php
        // Inicializa variáveis
        $nome = '';
        $preco = '';
        $quantidade = '';
        $total = 0;
        
        // Verifica se o formulário foi enviado
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Obtém os valores do formulário
            $nome = $_POST["nome"] ?? '';
            $preco = floatval($_POST["preco"] ?? 0);
            $quantidade = intval($_POST["quantidade"] ?? 0);
            
            // Calcula o total
            $total = $preco * $quantidade;
        }
        ?>
        
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="nome">Nome do Produto:</label>
                <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="preco">Preço Unitário (R$):</label>
                <input type="number" id="preco" name="preco" step="0.01" min="0" value="<?php echo $preco; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="quantidade">Quantidade:</label>
                <input type="number" id="quantidade" name="quantidade" min="1" value="<?php echo $quantidade; ?>" required>
            </div>
            
            <button type="submit">Calcular Total</button>
        </form>
        
        <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
            <div class="result">
                <h3>Resultado:</h3>
                <p><strong>Produto:</strong> <?php echo htmlspecialchars($nome); ?></p>
                <p><strong>Preço Unitário:</strong> R$ <?php echo number_format($preco, 2, ',', '.'); ?></p>
                <p><strong>Quantidade:</strong> <?php echo $quantidade; ?></p>
                <p><strong>Total:</strong> R$ <?php echo number_format($total, 2, ',', '.'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>