<?php
// Array com as cores primárias
$coresPrimarias = ["vermelho", "azul", "amarelo"];

// Cor a ser verificada (pode ser alterada para testar)
$novaCor = "verde"; // Experimente mudar para "azul" ou outra cor

// Verifica se a cor existe no array
$ehPrimaria = in_array(strtolower($novaCor), $coresPrimarias);

// Exibição formatada
echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Verificador de Cores Primárias</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 30px;
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 20px;
        }
        .cor-box {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            border-radius: 5px;
            font-weight: bold;
            background-color: #f0f0f0;
        }
        .resultado {
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
            font-size: 1.2em;
            font-weight: bold;
        }
        .primaria {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .nao-primaria {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .lista-cores {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 20px 0;
        }
        .cor-item {
            padding: 8px 15px;
            border-radius: 20px;
            color: white;
            font-weight: bold;
            text-shadow: 0 1px 1px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🎨 Verificador de Cores Primárias</h1>
        
        <div class='cor-box' style='background-color: " . 
            (strtolower($novaCor) === 'vermelho' ? '#ff0000' : 
             (strtolower($novaCor) === 'azul' ? '#0000ff' : 
              (strtolower($novaCor) === 'amarelo' ? '#ffff00' : '#cccccc'))) . 
            ";'>" . htmlspecialchars(ucfirst($novaCor)) . "</div>
        
        <div class='lista-cores'>
            <div class='cor-item' style='background-color: #ff0000;'>Vermelho</div>
            <div class='cor-item' style='background-color: #0000ff;'>Azul</div>
            <div class='cor-item' style='background-color: #ffff00;'>Amarelo</div>
        </div>
        
        <div class='resultado " . ($ehPrimaria ? "primaria" : "nao-primaria") . "'>
            A cor <strong>" . htmlspecialchars($novaCor) . "</strong> " . 
            ($ehPrimaria ? "é" : "não é") . " uma cor primária.
        </div>
    </div>
</body>
</html>";
?>