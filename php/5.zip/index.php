<?php
// Array indexado com 5 itens de supermercado
$listaDeCompras = [
    "Arroz integral",
    "Feijão preto",
    "Azeite de oliva",
    "Frutas variadas",
    "Iogurte natural"
];

// Exibição da lista com formatação HTML
echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Lista de Compras</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
        }
        .lista-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 25px;
            width: 100%;
            max-width: 500px;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 20px;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            padding: 12px 15px;
            margin: 8px 0;
            background-color: #f1f8fe;
            border-left: 4px solid #3498db;
            border-radius: 4px;
            font-size: 1.1em;
        }
        li:hover {
            background-color: #e3f2fd;
            transform: translateX(5px);
            transition: all 0.3s ease;
        }
    </style>
</head>
<body>
    <div class='lista-container'>
        <h1>📋 Minha Lista de Compras</h1>
        <ul>";

// Loop for para exibir cada item
for ($i = 0; $i < count($listaDeCompras); $i++) {
    echo "<li>" . ($i + 1) . ". " . htmlspecialchars($listaDeCompras[$i]) . "</li>";
}

echo "
        </ul>
    </div>
</body>
</html>";
?>