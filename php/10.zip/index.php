<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Livro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Estilo personalizado para a fonte Inter */
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white p-8 rounded-lg shadow-xl max-w-md w-full">
        <h1 class="text-3xl font-bold text-gray-800 mb-6 text-center">Detalhes do Livro</h1>

        <?php
        // 1. Criação do array associativo $livro
        $livro = [
            "titulo" => "O Pequeno Príncipe",
            "autor" => "Antoine de Saint-Exupéry",
            "ano" => 1943,
            "genero" => "Fábula"
        ];

        // 2. Exibição das informações do livro formatadas de forma legível
        echo "<div class='space-y-4'>";
        echo "<p class='text-gray-700'><strong class='font-semibold text-gray-900'>Título:</strong> " . htmlspecialchars($livro["titulo"]) . "</p>";
        echo "<p class='text-gray-700'><strong class='font-semibold text-gray-900'>Autor:</strong> " . htmlspecialchars($livro["autor"]) . "</p>";
        echo "<p class='text-gray-700'><strong class='font-semibold text-gray-900'>Ano de Publicação:</strong> " . htmlspecialchars($livro["ano"]) . "</p>";
        echo "<p class='text-gray-700'><strong class='font-semibold text-gray-900'>Gênero:</strong> " . htmlspecialchars($livro["genero"]) . "</p>";
        echo "</div>";
        ?>
    </div>
</body>
</html>
