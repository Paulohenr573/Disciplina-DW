<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Dados Pessoais</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        h1 {
            color: #2c3e50;
            margin-bottom: 20px;
        }
        .info {
            margin: 15px 0;
            text-align: left;
            padding-left: 20px;
        }
        .info strong {
            color: #3498db;
            display: inline-block;
            width: 80px;
        }
        .highlight {
            background-color: #e3f2fd;
            padding: 10px;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Meus Dados Pessoais</h1>
        
        <div class="info">
            <strong>Nome:</strong> Paulo Henrique Andrade Geraldi
        </div>
        
        <div class="info">
            <strong>Idade:</strong> 30 anos
        </div>
        
        <div class="info">
            <strong>Cidade:</strong> Sinop/MT
        </div>
        
        <div class="info">
            <strong>Hobby:</strong> Ler e ver animes
        </div>
        
        <div class="info">
            <strong>Curso:</strong> Sistemas de Informação
        </div>
        
        <div class="highlight">
            <?php
                echo "Última atualização: " . date("d/m/Y H:i:s");
            ?>
        </div>
    </div>
</body>
</html>