<?php
// Array indexado com 7 nomes
$nomes = [
    "Ana", 
    "Bruno", 
    "Carlos", 
    "Daniela", 
    "Eduardo", 
    "Fernanda", 
    "Gustavo"
];

// Seleciona um índice aleatório
$indiceAleatorio = array_rand($nomes);
$nomeSelecionado = $nomes[$indiceAleatorio];

// Exibição formatada
echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Seleção Aleatória de Nomes</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 25px;
            width: 100%;
            max-width: 500px;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 20px;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            padding: 10px;
            margin: 5px 0;
            background-color: #f1f8fe;
            border-radius: 5px;
        }
        .destaque {
            background-color: #e3f2fd;
            border-left: 4px solid #3498db;
            font-weight: bold;
            padding: 15px;
            margin-top: 20px;
            text-align: center;
            font-size: 1.2em;
        }
        .sorteado {
            color: #e74c3c;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🔢 Lista de Nomes</h1>
        
        <h3>Todos os nomes:</h3>
        <ul>";

// Exibe todos os nomes
foreach ($nomes as $indice => $nome) {
    echo "<li>" . ($indice + 1) . ". " . htmlspecialchars($nome) . "</li>";
}

echo "
        </ul>
        
        <div class='destaque'>
            Nome selecionado aleatoriamente: 
            <span class='sorteado'>" . htmlspecialchars($nomeSelecionado) . "</span>
        </div>
    </div>
</body>
</html>";
?>