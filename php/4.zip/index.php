<?php
// Array associativo com informações do produto
$produto = [
    'nome' => 'Smartphone Galaxy S23',
    'preco' => 4299.99,
    'estoque' => 15
];

// Variáveis para cálculo
$desconto = 10; // 10%
$preco_com_desconto = $produto['preco'] * (1 - ($desconto / 100));

// Exibição formatada
echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Informações do Produto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
        }
        .produto {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            max-width: 500px;
            margin: 0 auto;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .info {
            margin: 15px 0;
        }
        .preco-original {
            text-decoration: line-through;
            color: #e74c3c;
        }
        .preco-desconto {
            font-size: 1.5em;
            color: #27ae60;
            font-weight: bold;
        }
        .estoque {
            color: #3498db;
        }
    </style>
</head>
<body>
    <div class='produto'>
        <h1>{$produto['nome']}</h1>
        
        <div class='info'>
            <span class='preco-original'>Preço original: R$ " . number_format($produto['preco'], 2, ',', '.') . "</span>
        </div>
        
        <div class='info'>
            <span class='preco-desconto'>Preço com {$desconto}% de desconto: R$ " . number_format($preco_com_desconto, 2, ',', '.') . "</span>
        </div>
        
        <div class='info estoque'>
            Estoque disponível: {$produto['estoque']} unidades
        </div>
    </div>
</body>
</html>";
?>