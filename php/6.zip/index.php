<?php
// Array indexado com as notas do aluno em 4 disciplinas
$notas = [
    7.5,  // Nota 1 - Matemática
    8.2,  // Nota 2 - Português
    6.8,  // Nota 3 - História
    9.1   // Nota 4 - Ciências
];

// Cálculo da média
$soma = array_sum($notas);
$quantidade = count($notas);
$media = $soma / $quantidade;

// Exibição formatada
echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Boletim do Aluno</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
        }
        .boletim {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 25px;
            width: 100%;
            max-width: 500px;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #3498db;
            color: white;
        }
        .media {
            font-size: 1.2em;
            font-weight: bold;
            text-align: center;
            padding: 15px;
            background-color: #e3f2fd;
            border-radius: 5px;
        }
        .aprovado {
            color: #27ae60;
        }
        .recuperacao {
            color: #f39c12;
        }
        .reprovado {
            color: #e74c3c;
        }
    </style>
</head>
<body>
    <div class='boletim'>
        <h1>📊 Boletim Escolar</h1>
        
        <table>
            <thead>
                <tr>
                    <th>Disciplina</th>
                    <th>Nota</th>
                </tr>
            </thead>
            <tbody>";

// Loop para exibir cada disciplina e nota
$disciplinas = ["Matemática", "Português", "História", "Ciências"];
for ($i = 0; $i < count($notas); $i++) {
    echo "<tr>
            <td>{$disciplinas[$i]}</td>
            <td>{$notas[$i]}</td>
          </tr>";
}

echo "
            </tbody>
        </table>
        
        <div class='media ";

// Adiciona classe CSS conforme a média
if ($media >= 7) {
    echo "aprovado'>🎉 Média Final: {$media} - Aprovado!";
} elseif ($media >= 5) {
    echo "recuperacao'>⚠️ Média Final: {$media} - Recuperação";
} else {
    echo "reprovado'>😢 Média Final: {$media} - Reprovado";
}

echo "</div>
    </div>
</body>
</html>";
?>