<?php
// Array de clientes (cada cliente é um array associativo)
$clientes = [
    [
        'nome' => 'Ana Silva',
        'email' => 'ana.silva@example.com'
    ],
    [
        'nome' => 'Bruno Oliveira',
        'email' => 'bruno.oliveira@example.com'
    ],
    [
        'nome' => 'Carla Souza',
        'email' => 'carla.souza@example.com'
    ]
];

// Exibição formatada
echo "<!DOCTYPE html>
<html lang='pt-BR'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Cadastro de Clientes</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
        }
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 25px;
            width: 100%;
            max-width: 600px;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 25px;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background-color: #3498db;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        tr:hover {
            background-color: #e3f2fd;
        }
        .total {
            margin-top: 20px;
            font-weight: bold;
            text-align: right;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>📋 Cadastro de Clientes</h1>
        
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                </tr>
            </thead>
            <tbody>";

// Percorre o array de clientes
foreach ($clientes as $indice => $cliente) {
    echo "<tr>
            <td>" . ($indice + 1) . "</td>
            <td>" . htmlspecialchars($cliente['nome']) . "</td>
            <td>" . htmlspecialchars($cliente['email']) . "</td>
          </tr>";
}

echo "
            </tbody>
        </table>
        
        <div class='total'>
            Total de clientes: " . count($clientes) . "
        </div>
    </div>
</body>
</html>";
?>